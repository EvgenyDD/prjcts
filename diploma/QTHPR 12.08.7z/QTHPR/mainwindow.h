#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

#include <QSerialPort>
#include <QSerialPortInfo>
#include <QTimer>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    QSerialPort serial;

private slots:
    void on_pushButton_clicked();  

   // void on_comboBox_activated(int index);

    void on_pushButton_2_clicked();

   // void on_comboBox_activated(const QString &arg1);

    void on_pushButton_3_clicked();

   // void on_lineEdit_editingFinished();

   // void on_lineEdit_textChanged(const QString &arg1);

    void on_pushButton_5_clicked();

    void on_tabWidget_tabBarClicked(int);

    void on_tabWidget_currentChanged(int index);

    void on_pushButton_6_clicked();

    void on_pushButton_7_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_8_clicked();

    void on_pushButton_9_clicked();

public slots:
   // void handleAction();
    void DataReceive();
    void MonitoringFunction();

    bool parse_message(QString all_message);
    QByteArray Gener_Message(unsigned int number);//функция добавления параметров, служебных символов и подсчтёта контрольных сумм
    void ConnectComPort();
    void reset();
    void test();
    QString Scissors_Fun(QString &source_str, QString &drain_str, uint first_symb, uint last_symb);
    QString Return_Error(uint error_code);
    QString Return_State(uint state_code);

private:
    Ui::MainWindow *ui;
    QTimer m_timer;
    QTimer c_timer, reset_timer, test_timer;
    int _index;
    bool permiteMonitoring=1;
    bool stopButton=1;

};

#endif // MAINWINDOW_H
