#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>

#include <QSerialPort>
#include <QSerialPortInfo>

#include <QMessageBox>
#include <QFile>
#include "passworddialog.h"


QByteArray array; // глобальная переменная для сохранения принятого сообщения при неоднократном вызове слота DataReceive()
QString line1, current;
uint counter=0;
int list[]={14, 16, 25, 23, 27, 28};

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    m_timer.start(200);// запуск таймера для мониторинга
    c_timer.start(1000); // установка соединения с COM портом

    connect(&serial, SIGNAL(readyRead()), this, SLOT(DataReceive()));
    connect(&m_timer, SIGNAL(timeout()), this, SLOT(MonitoringFunction())); //считывание данных из источника (раз в 3 секунды)
    connect(&c_timer, SIGNAL(timeout()), this, SLOT(ConnectComPort())); // тест подключения к КОМ порту (при старте программы, 1 раз в 2 секунды)
    connect(&reset_timer, SIGNAL(timeout()), this, SLOT(reset()));
   connect(&test_timer, SIGNAL(timeout()), this, SLOT(test()));

    /*   serial.write(Gener_Message(2));
    serial.write(Gener_Message(3));
    serial.write(Gener_Message(5));
    serial.write(Gener_Message(13));*/

    foreach (const QSerialPortInfo &info, QSerialPortInfo::availablePorts())
        ui->comboBox->addItem(info.portName());
    serial.setPortName("COM3");
    serial.setBaudRate(QSerialPort::Baud19200);
    serial.setDataBits(QSerialPort::Data8);
    serial.setParity(QSerialPort::NoParity);
    serial.setStopBits(QSerialPort::OneStop);
    serial.setFlowControl(QSerialPort::NoFlowControl);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::reset()
{
    permiteMonitoring=1;
    stopButton=1;
    m_timer.start(200);
    reset_timer.stop();
}

void MainWindow::test()
{
   serial.write(Gener_Message(29));
   // serial.write(Gener_Message(3));
}



void MainWindow::ConnectComPort()

{

    if (serial.open(QIODevice::ReadWrite)) //остановка таймера при удавшемся подключении
    {
        c_timer.stop();
        //serial.write(Gener_Message(5));

        serial.write(Gener_Message(20));
        serial.write(Gener_Message(22));
        serial.write(Gener_Message(14));
        serial.write(Gener_Message(16));
        ui->lineEdit->setText(current);
    }
    else
        QMessageBox::information(this, "Error", "Не возможно установить соединение!");


}

void MainWindow::MonitoringFunction() // мониторинг данных
{
   // QString error, one_param;
   // uint begin1=0, line_end1=0;

   // if(permiteMonitoring == 1)

        if(stopButton)
  //  {
        if(!(ui->pushButton_4->isChecked() or ui->pushButton_5->isChecked())) //
        {
            if(permiteMonitoring == 1)
            serial.write(Gener_Message(list[counter]));
        }

        else
        {
            serial.write(Gener_Message(22));
        }


//    }

  /*  error=Return_Error(ui->lineEdit_15->text().toInt());
    if(error.length()>1)
    {
        for(uint i=0; error[i]!='{'; i++) //определение начала названия ошибки
            begin1++;
        for(uint j=begin1+1; error[j]!='}'; j++) //определение конца названия ошибки
            line_end1++;
        ui->lineEdit_16->setText(Scissors_Fun(error, one_param, begin1+1, line_end1));
    }
    ui->lineEdit_16->setText("No Error");*/


}

QByteArray MainWindow::Gener_Message(unsigned int number)  //функция добавления параметров, служебных символов и контрольных сумм
{
    QString temp, str, buffer;
    QByteArray message;
    unsigned int i, summ=0;
    permiteMonitoring=0;
    switch(number) //выбор отправляемого сообщения и добавление параметров
    {
    case 0: temp=">000"; break; //HELLO; передаваемые данные отсутствуют; возвращает строку идентифицирующую систему
    case 1: temp=">001"; break; //VERSION; передаваемые данные отсутствуют; возвращет строку с версиями программы источника тока и управления газа через пробел
    case 2: temp=">002"; break; //GET_STATE; передаваемые данные отсутствуют; возвращает код состояния;
    case 3: temp=">003"; break; //LAST_ERROR; передаваемые данные отсутствуют; возвращает код последней ошибки;
    case 4: temp=">004"; break; //REMOTE_MODE; передаваемые данные отсутствуют; возвращает: 1 - принята, 0 - не принята; перевести систему в дистанционный режим
    case 5: temp=">028"; break; //READ_PLASMA_AMPS; передаваемые данные отсутствуют; возвращает ток источника в амперах; считывает действительное значение тока
    case 6: temp=">058"; temp=temp.append(ui->lineEdit->text()); break; //SET_NOMINAL_AMPS; передаваемые данные: 5-250А; возвращает фактически установленное значение тока; задаёт номинальную силу тока
    case 7: temp=">064"; break; //GAS_PREFLOW_GAS_PREFLOW_TEST_START; передаваемые данные отсутствуют; возвращает: 1 - принята, 0 - не принята; включить подачу газов до возбуждени дуги, не вкл. во время резки;
    case 8: temp=">065"; break; //GAS_PREFLOW_GAS_TEST_STOP; передаваемые данные отсутствуют; возвращает: 1 - принята, 0 - не принята; выключить подачу газов до возбуждени дуги, не выкл. во время резки;
    case 9: temp=">066"; break; //GAS_CUTFLOW_TEST_START; передаваемые данные отсутствуют; возвращает: 1 - принята, 0 - не принята; вкл. подачу режущих газов, не вкл. во время резки;
    case 10: temp=">067"; break; //GAS_CUTFLOW_TEST_STOP; передаваемые данные отсутствуют; возвращает: 1 - принята, 0 - не принята; выкл. подачу режущих газов, не выкл. во время резки;
    case 11: temp=">068"; break; //SYSTEM_RESET; передаваемые данные отсутствуют; возвращает: 1 - принята, 0 - не принята; сброс системы при состоянии = 14 и коде ошибки > 79
    case 12: temp=">070"; temp=temp.append(ui->lineEdit_2->text()); break; //SET_CORNER_CURRENT передаваемые данные: 50-100% от тока резки; возвращает достигнутое значение в %;
    case 13: temp=">071";
    {
        if(ui->pushButton_8->isChecked())
            temp=temp.append("1");
        else
            temp=temp.append("0");
    }
    break; //MANUAL_PUMP_CONTROL; передаваемые данные: 1 - подавить прог. упр. для принудительного включения насосом, 0 - насос управляется системным ПО (подавление выключено); возвращает: 1 - принята, 0 - не принята; подавить ручное управление насосом
    case 14: temp=">072"; break; //GET_CONTROL_VOLTAGE; передаваемые данные отсутствуют; возвращает: величину напряжения (1/10В); внутреннее управляющее напряжение;
    case 15: //SET_ALL_GAS_FLOWS; данные: через пробел - подача плазм. газа при резке, подача плазм. газа д возб. дуги
    {
        temp=">078";
        temp=temp.append(ui->lineEdit_10->text());
        temp=temp.append(' ');
        temp=temp.append(ui->lineEdit_9->text());
        temp=temp.append(' ');
        temp=temp.append(ui->lineEdit_11->text());
        temp=temp.append(' ');
        temp=temp.append(ui->lineEdit_12->text());
        temp=temp.append(' ');
        temp=temp.append("0"); // N2 откуда????
        temp=temp.append(' ');
        temp=temp.append("0"); // GAS2 откуда????

    }
        break;
    case 16: temp=">079"; break; // GET_PS_INFO; передаваемые данные отсутствуют; возвращает: 1 - давление пл. газа при резке, 2 - давление пл. газа до возбуждения дуги, 3 - давление защ. газа при резке, 4 - давление защ. газа до возбуждения дуги, 5 - заданное значение тока (в амперах), 6 - состояние системы, 7 - системная ошибка, 8 - давление режущего газа 1, 9 - давление режущего газа 2, 10 - давление на входе смеси N2, 11 - давление на входе смеси GAS2. Получить информацию из плазменной системы.
    case 17:  // SET_ALL_PARAMETRES; передаваемые данные: 1 - заданное значение тока (5-130/260/400А), 2 - процентная доля тока поворота (50-100%), 3 - код типа плазмообразующего газа, 4 - код типа защитного газа, 5 - заданное значение расхода плазм. газа при резке, 6 - заданное значение расхода плазмообр. газа до возбуждения дуги, 7 - заданное значение расхода защитн. газа при резке, 8 - заданное значение расхода защитн. газа до возбуждения дуги, 9 - заданное значение для смеси N2, 10 - заданное значение для смеси Gas2; возвр. значение: 1 -принята, 0 - не принята. Задать все переменные для работы плазменной системы.
    {
        temp=">095";
        temp=temp.append(ui->lineEdit->text());
        current=ui->lineEdit->text();
        temp=temp.append(' ');
        temp=temp.append(ui->lineEdit_2->text());
        temp=temp.append(' ');
        temp=temp.append(temp.number(ui->comboBox_2->currentIndex()));
        temp=temp.append(' ');
        temp=temp.append(temp.number(ui->comboBox_3->currentIndex()));
        temp=temp.append(' ');
        temp=temp.append(ui->lineEdit_10->text());
        temp=temp.append(' ');
        temp=temp.append(ui->lineEdit_9->text());
        temp=temp.append(' ');
        temp=temp.append(ui->lineEdit_11->text());
        temp=temp.append(' ');
        temp=temp.append(ui->lineEdit_12->text());
        temp=temp.append(' ');
        temp=temp.append("0");// N2 откуда???? Паша сказал что ебашим по нулям
        temp=temp.append(' ');
        temp=temp.append("0");// GAS2 откуда????

    }
        break;
    case 19: temp=">096";  // SET_INLET_GASES; передаваемые данные: 1 - код типа плазмообразующего газа, 2 - код типа защитного газа; возвр. значение: 1 -принята, 0 - не принята. Задать поступающие газы.
    {
        temp=temp.append(temp.number(ui->comboBox_2->currentIndex()));
        temp=temp.append(' ');
        temp=temp.append(temp.number(ui->comboBox_3->currentIndex()));
    }
        break;
    case 20: temp=">097"; break; //READ_CORNER_CURRENT; передаваемые данные отсутствуют; возвращает: процентное значение. Считать ток поворота.
    case 21: temp=">098"; break; //GET_INLET_GASES; передаваемые данные отсутствуют; возвращает: 1 - код типа плам. газа, 2 - код типа защ. газа; Считать сведения о поступающих газах.
    case 22: temp=">099"; break; //GET_GAS_FLOWS; передаваемые данные отсутствуют; возвращает: 1 - заданное значение расхода плазм. газа при резке, 2 - заданное значение расхода плазмообр. газа до возбуждения дуги, 3 - заданное значение расхода защитн. газа при резке, 4 - заданное значение расхода защитн. газа до возбуждения дуги, 5 - заданное значение для смеси N2, 6 - заданное значение для смеси Gas2. Считать заданные значения для газов;
    case 23: temp=">100"; break; //GET_CONTROL_DATA; передаваемые данные отсутствуют; возвращает:
    case 24: temp=">121"; break; //LEAK_CHECK_MODE; передаваемые данные: режим 0 - работа, 1 - проверка на герметичность на входе, 2 - тест на герметичность системы, 3 - проверка потока через клапан Burkert; возвращает: время выполнения теста в секундах, 0 - команда не принята . Режим проверки на утечки
    case 25: temp=">125"; break; //GET_TIMER_COUNTER; передаваемые данные отсутствуют; возвращает: . Считать счетчик времени
    case 26: temp=">131"; break; //CLEAR WARNINGS; сбрасывает коды ошибок менее 43
    case 27: temp=">132"; break; //READ COOLANT PRESSURE; считать давление охлаждающей жидкости;
    case 28: temp=">134"; break; //READ ERROR LOG; передаваемые данные отсутствуют;
    case 29: temp=">094";  break; //

    default: temp="error!"; break;
    }

    for(i=1; i<temp.length(); i++)  // подсчёт контрольной суммы отправляемого сообщения
    {
        //   if(temp[i] != ' ') //обработка пробелов
        //   {
        // qDebug()<<temp[i].unicode();//для отладки
        summ+=temp[i].unicode();
        //  }
        //  else qDebug()<<"lol";
    }

    str=QString::number(summ, 16); //перевод в 16-ричное значение
    str=str.toUpper(); // коррекция нижнего регистра
    if(str.length()>2) // оставляем только 2 младших байта (разряда).
    {
        buffer=str;
        str.clear();
        str[0]=buffer[1];
        str[1]=buffer[2];
        buffer.clear();
    }

    temp=temp.append(str); // добавляем контрольную сумму
    temp=temp.append("<"); // добавлем знак завершения сообщения
    //qDebug()<<str;
    ui->lineEdit_4->setText(temp);


    message=message.append(temp);
    permiteMonitoring=1;
    return message;

}



void MainWindow::on_pushButton_2_clicked() //функция чтения исходных данных из источника
{    
    m_timer.stop();

    serial.write(Gener_Message(20));
    serial.write(Gener_Message(22));
    serial.write(Gener_Message(14));
    serial.write(Gener_Message(16));
    ui->lineEdit->setText(current);
    m_timer.start(200);
}



void MainWindow::DataReceive() // функция прёма данных
{

    QByteArray buffer; //временный буффер для хранения прочитанных данных, живой только для перезаписи
    unsigned char CRCSumm=0;// подсчитанная контрольная сумма и полученная контрольная сумма
   permiteMonitoring=0;
    buffer=serial.readAll();
    array.append(buffer); // добавление буффера к сообщению (на случай если не все сообщение принялось сразу)
    buffer.clear(); // очистка буффера

    QString all_message=array, CRCRec, temp;
    if(all_message[all_message.length()-1]== '<') // выполняется по наличию завершающего символа в сообщении
    {

        array.clear(); // освобождаем память для нового сообщения
        for(unsigned int i=1; i<all_message.length()-3; i++) //перебор символов (кроме 1-го и 3-х последних) принятого сообщения
        {
            //qDebug()<<all_message[i].unicode();// отладка
            CRCSumm+=all_message[i].unicode(); // сумма ascii кодов всех символов цикла
        }
        temp=temp.number(CRCSumm, 16);// перевод в строку как 16-ричные данные

        if(temp.length()>2) // избавление от старшего разряда при сумме превышающей 99
        {
            temp[0]=temp[1];
            temp[1]=temp[2];
            temp[3]=' ';
        }

        temp=temp.toUpper(); // перевод симовлов к верхнему регистру
        qDebug()<<temp;
        CRCRec=all_message[all_message.length()-3]; // первый символ полученной CRC
        CRCRec=CRCRec.append(all_message[all_message.length()-2]); // второй символ полученной CRC

        qDebug()<<CRCRec;
       if(temp.toInt(0, 16) == CRCRec.toInt(0, 16))// if(temp[0] == CRCRec[0] && temp[1] == CRCRec[1]) // сравнение контрольных сумм
        {

          //  qDebug()<<temp.toInt();
           // qDebug()<<CRCRec.toInt();
            qDebug()<<"True";
         //   qDebug()<<all_message;
            // if(parse_message(all_message));// вызов обработчика проверенного сообщения
            // QMessageBox::information(this, "Ответ системы", "Команда не принята");
            parse_message(all_message);
            permiteMonitoring=1;

            if(counter!= 5)
                counter++;
            else counter=0;
        }
        else
        {
            qDebug()<<"CRC False";
           // for(unsigned int i=1; i<all_message.length()-1; i++)
            //    qDebug()<<all_message[i].unicode()<<"   "<<all_message[i];
            qDebug()<<CRCSumm;
            qDebug()<<CRCRec;
            all_message="CRC FALSE";
        }

        ui->lineEdit_4->clear();
        ui->lineEdit_4->setText(all_message);
    }



}

bool MainWindow::parse_message(QString all_message)
{
    QString code_string, one_param, state_code, error_code;
    for(uint i=1; i<4; i++)
        code_string[i-1]=all_message[i];
    uint code_int=code_string.toUInt();
    //qDebug()<<code_int;

    //    all_message.
    switch(code_int)
    {

    case 3:
    {
        state_code=Scissors_Fun(all_message, one_param, 5, 4);
        ui->lineEdit_13->setText(state_code);
        ui->lineEdit_14->setText(Return_State(state_code.toUInt()));
    }

     break;
    case 28:
    {
        if(all_message[5]!='0')
            ui->lineEdit->setText(Scissors_Fun(all_message, one_param, 3, 3));
        else
            ui->lineEdit->setText(Scissors_Fun(all_message, one_param, 6, 2));
    }

    case 72:
    {
        float temp=Scissors_Fun(all_message, one_param, 4, 4).toFloat()/10;
        QString str=str.number(temp);
        ui->lineEdit_21->setText(str);
    }
    break;
    case 79: // для постоянного мониторинга
    {
        QString str=str.number(Scissors_Fun(all_message, one_param, 6, 4).toInt());
        ui->lineEdit_28->setText(str);

        str=str.number(Scissors_Fun(all_message, one_param, 13, 4).toInt());
        ui->lineEdit_27->setText(str);

         str=str.number(Scissors_Fun(all_message, one_param, 20, 4).toInt());
        ui->lineEdit_29->setText(str);

         str=str.number(Scissors_Fun(all_message, one_param, 27, 4).toInt());
        ui->lineEdit_31->setText(str);

        str=str.number(Scissors_Fun(all_message, one_param, 34, 4).toInt());
        //ui->lineEdit->setText(str);
        current=str;
        //тут должен быть ток в амперах но мы его не юзаем поэтому количество символов +14 а не +7

        state_code=Scissors_Fun(all_message, one_param, 41, 4);
        ui->lineEdit_13->setText(state_code);
        ui->lineEdit_14->setText(Return_State(state_code.toUInt()));

        error_code=Scissors_Fun(all_message, one_param, 48, 4);
        ui->lineEdit_15->setText(error_code);//

        str=str.number(Scissors_Fun(all_message, one_param, 55, 4).toInt());
        ui->lineEdit_30->setText(str);

        str=str.number(Scissors_Fun(all_message, one_param, 62, 4).toInt());
        ui->lineEdit_32->setText(str);

        str=str.number(Scissors_Fun(all_message, one_param, 69, 4).toInt());
        ui->lineEdit_34->setText(str);

        str=str.number(Scissors_Fun(all_message, one_param, 76, 4).toInt());
        ui->lineEdit_33->setText(str);


    }
    break;

    case 94: // текущие значения газов (не используем, т.к. 79 более няшная комманда)
    {
        if(ui->pushButton_5->isChecked())
       {
            ui->lineEdit_3->setText(Scissors_Fun(all_message, one_param, 13, 4));
          ui->lineEdit_6->setText(Scissors_Fun(all_message, one_param, 27, 4));

          ui->lineEdit_7->setText("");//
          ui->lineEdit_8->setText("");

    }
        if(ui->pushButton_4->isChecked())
    {
            ui->lineEdit_7->setText(Scissors_Fun(all_message, one_param, 6, 4));//
            ui->lineEdit_8->setText(Scissors_Fun(all_message, one_param, 20, 4));

            ui->lineEdit_3->setText("");
          ui->lineEdit_6->setText("");
        }
    }
    break;

    case 97: // Считать ток поворота
    {
        if(all_message[5] == '1')
            ui->lineEdit_2->setText(Scissors_Fun(all_message, one_param, 5, 3));
        else
            ui->lineEdit_2->setText(Scissors_Fun(all_message, one_param, 6, 2));
    }
    break;

    case 99: // Считать !заданные! значения для газов
    {
        QString str=str.number(Scissors_Fun(all_message, one_param, 4, 4).toInt());
        ui->lineEdit_10->setText(str);

        str=str.number(Scissors_Fun(all_message, one_param, 9, 4).toInt());
        ui->lineEdit_9->setText(str);

        str=str.number(Scissors_Fun(all_message, one_param, 15, 4).toInt());
        ui->lineEdit_11->setText(str);

        str=str.number(Scissors_Fun(all_message, one_param, 19, 4).toInt());
        ui->lineEdit_12->setText(str);

    }
    break;

    case 100:
    {
        QString str=str.number(Scissors_Fun(all_message, one_param, 7, 4).toInt());
        ui->lineEdit_46->setText(str);

        str=str.number(Scissors_Fun(all_message, one_param, 15, 4).toInt());
        ui->lineEdit_47->setText(str);

        str=str.number(Scissors_Fun(all_message, one_param, 23, 4).toFloat()/10);
        ui->lineEdit_21->setText(str);

        str=str.number(Scissors_Fun(all_message, one_param, 31, 4).toFloat()/100);
        ui->lineEdit_24->setText(str);

        str=str.number(Scissors_Fun(all_message, one_param, 39, 4).toInt());// температура
        ui->lineEdit_26->setText(str);

        str=str.number(Scissors_Fun(all_message, one_param, 47, 4).toInt());
        ui->lineEdit_23->setText(str);

        str=str.number(Scissors_Fun(all_message, one_param, 55, 4).toInt());
        ui->lineEdit_42->setText(str);

        str=str.number(Scissors_Fun(all_message, one_param, 63, 4).toInt());
        ui->lineEdit_43->setText(str);

        str=str.number(Scissors_Fun(all_message, one_param, 71, 4).toInt());
        ui->lineEdit_22->setText(str);

        str=str.number(Scissors_Fun(all_message, one_param, 79, 4).toInt());
        ui->lineEdit_39->setText(str);

        str=str.number(Scissors_Fun(all_message, one_param, 88, 4).toInt());
        ui->lineEdit_41->setText(str);

        str=str.number(Scissors_Fun(all_message, one_param, 97, 4).toInt());
        ui->lineEdit_44->setText(str);

        str=str.number(Scissors_Fun(all_message, one_param, 97, 4).toInt());
        ui->lineEdit_45->setText(str);

    }
    break;

    case 125:
    {
        QString str=str.number(Scissors_Fun(all_message, one_param, 4, 7).toInt());
        ui->lineEdit_36->setText(str);

        str=str.number(Scissors_Fun(all_message, one_param, 12, 7).toInt());
        ui->lineEdit_35->setText(str);

        str=str.number(Scissors_Fun(all_message, one_param, 20, 7).toInt());
        ui->lineEdit_37->setText(str);

        str=str.number(Scissors_Fun(all_message, one_param, 28, 7).toInt());
        ui->lineEdit_40->setText(str);

        str=str.number(Scissors_Fun(all_message, one_param, 36, 7).toInt());
        ui->lineEdit_38->setText(str);
    }
    break;

    case 132:
    {
        QString str=str.number(Scissors_Fun(all_message, one_param, 4, 2).toFloat()*2.71);
        ui->lineEdit_25->setText(str);
    }
    break;

    case 134:
    {
        QString str=str.number(Scissors_Fun(all_message, one_param, 4, 4).toInt());
        ui->lineEdit_17->setText(str);

        str=str.number(Scissors_Fun(all_message, one_param, 9, 4).toInt());
        ui->lineEdit_18->setText(str);

        str=str.number(Scissors_Fun(all_message, one_param, 14, 4).toInt());
        ui->lineEdit_19->setText(str);

        str=str.number(Scissors_Fun(all_message, one_param, 19, 4).toInt());
        ui->lineEdit_20->setText(str);
    }
    break;
    case 64:
    {

        if(all_message[4] == '1')
        {
            test_timer.start(300);
        }
        else
            QMessageBox::warning(this, "Ошибка", "Тест не может быть выполнен.");
    }
    break;

    case 65:
    {
        if(all_message[4] == '1')
            test_timer.stop();
        else
            QMessageBox::warning(this, "Ошибка", "Тест не может быть завершен.");
    }
    break;
    case 66:
    {
        if(all_message[4] == '1')
            test_timer.start(300);
        else
            QMessageBox::warning(this, "Ошибка", "Тест не может быть выполнен.");
    }
    break;

    case 67:
    {
        if(all_message[4] == '1')
            test_timer.stop();
        else
            QMessageBox::warning(this, "Ошибка", "Тест не может быть завершен.");
    }
    break;
    default: break;
    }

    return 1;
}

QString MainWindow::Return_Error(uint error_code)//сделать не через свитч, а читать данные из файла
{
    QFile file("errors.txt");
    QString error, one_param;
    int error_id=0;

    if (file.open(QIODevice::ReadOnly))
    {
       //QMessageBox::warning(this, "Диалог открытия файла", "Файл открыт");
        for(uint i=0; (error_id!=error_code); i++)
        {
            error=file.readLine();
            error_id=Scissors_Fun(error, one_param, 0, 3).toInt();

            //qDebug()<<state_id;
        }

    }

    file.close();    
   return error;
}

QString MainWindow::Return_State(uint state_code)//сделать не через свитч, а читать данные из файла
{
    QString state, ret_message, one_param;
    uint state_id, begin=0;

    QFile file("states.txt");
    qDebug()<<"StateCOde"<<" "<<state_code;

    if (file.open(QIODevice::ReadOnly))
    {
       //QMessageBox::warning(this, "Диалог открытия файла", "Файл открыт");

       //while(state_id!=state_code) // нахождение строки с идентификатором

       for(uint i=0; state_id!=state_code; i++)
       {
           state=file.readLine();
           state_id=Scissors_Fun(state, one_param, 0, 2).toUInt();
           //qDebug()<<state_id;

       }
        // QMessageBox::warning(this, "Диалог открытия файла", Scissors_Fun(state, one_param, 0, 2));
       for(uint i=0; state[i]!='('; i++) //определение начала описания состояния
           begin++;

       for(uint i=begin+1, j=0; i<state.length()-3; i++, j++)
           ret_message[j]=state[i];


      //  QMessageBox::warning(this, "Диалог открытия файла", ret_message);
    }
    //else
      //  qDebug()<<"dont working!";

    file.close();


    return ret_message;
}

QString MainWindow::Scissors_Fun(QString &source_str, QString &drain_str, uint first_symb, uint quantity_symb) //обрезает лишние символы, 1 - строка исходная, 2 - строка получатель и возвращаемая, 3 - номер символа с которого вырезаем строку, 4 - количество вырезаемых символов;- научиться работать со ссылками
{
    for(uint i=first_symb, j=0; i<first_symb+quantity_symb; i++, j++)
        drain_str[j]=source_str[i];

    return drain_str;
}

void MainWindow::on_tabWidget_tabBarClicked(int)
{
    _index = ui->tabWidget->currentIndex();
}

void MainWindow::on_tabWidget_currentChanged(int index)
{
    if (index == 2)
    {
       PasswordDialog dialog; // дичь
        //up(new Up::PasswordDialog);

        if (dialog.exec())//and checkServicePass()
            ui->tabWidget->setCurrentIndex(2);
        else
            ui->tabWidget->setCurrentIndex(_index);
    }
}

void MainWindow::on_pushButton_6_clicked() // вызов помощи
{
   QString error, one_param;
   uint begin1=0, line_end1=0;

   switch(ui->comboBox_5->currentIndex())
   {
       case 0: error=Return_Error(ui->lineEdit_15->text().toInt()); break;
       case 1: error=Return_Error(ui->lineEdit_17->text().toInt()); break;
       case 2: error=Return_Error(ui->lineEdit_18->text().toInt()); break;
       case 3: error=Return_Error(ui->lineEdit_19->text().toInt()); break;
       case 4: error=Return_Error(ui->lineEdit_20->text().toInt()); break;
       default: error=Return_Error(ui->lineEdit_15->text().toInt()); break;
   };

   if(error.length()>1)
   {
       for(uint i=0; error[i]!='{'; i++) //определение начала названия ошибки
           begin1++;
       for(uint j=begin1+1; error[j]!='}'; j++) //определение конца названия ошибки
           line_end1++;

       QMessageBox::warning(this, "Помощь", Scissors_Fun(error, one_param, begin1+line_end1+4, error.length()-(begin1+line_end1+4)-3)); //Scissors_Fun(error, one_param, begin1+1, line_end1)
   }
   else
        QMessageBox::warning(this, "NO ERROR", "Ошибки отсутствуют. Система готова к работе.");
}

void MainWindow::on_pushButton_7_clicked() //SYSTEM_RESET
{
    m_timer.stop();
    permiteMonitoring=0;
    stopButton=0;
   // ui->pushButton_9->click();
    serial.write(Gener_Message(11));
    reset_timer.start(10000);
}

void MainWindow::on_pushButton_4_clicked() //тест режущей подачи газов
{
    if(ui->pushButton_4->isChecked())
    {
        permiteMonitoring=0;
        stopButton=0;
        m_timer.stop();
        ui->pushButton_5->setDisabled(1);
        serial.write(Gener_Message(9));
    }
    else
    {
        serial.write(Gener_Message(10));
        ui->pushButton_5->setEnabled(1);
        permiteMonitoring=1;
        stopButton=1;
        m_timer.start(200);
    }
}

void MainWindow::on_pushButton_5_clicked() //тест продувочной подачи газов
{
    if(ui->pushButton_5->isChecked())
    {
        permiteMonitoring=0;
        stopButton=0;
        m_timer.stop();
        ui->pushButton_4->setDisabled(1);
        serial.write(Gener_Message(7));
    }
    else
    {
        serial.write(Gener_Message(8));
        ui->pushButton_4->setEnabled(1);
        permiteMonitoring=1;
        stopButton=1;
         QMessageBox::warning(this, "NO ERROR", "Тест выключен");
        m_timer.start(200);
    }
}

void MainWindow::on_pushButton_8_clicked() // ручное управление насосом
{

    serial.write(Gener_Message(13));

}

void MainWindow::on_pushButton_9_clicked() // вкл. выкл. мониторинг
{
    if(ui->pushButton_9->isChecked())
    {
        stopButton=0;
        permiteMonitoring = 0;
    }
    else
    {
        stopButton=1;
        permiteMonitoring = 1;
    }
}

void MainWindow::on_pushButton_3_clicked() // Запись данных в источник и проверка
{
        m_timer.stop();
        permiteMonitoring = 0;
        QString current, currentPercent, gasCutplasma, gasCutprotect, gasPreflowplasma, gasPreflowprotect;

        current=ui->lineEdit->text();
        currentPercent=ui->lineEdit_2->text();
        gasCutplasma=ui->lineEdit_10->text();
        gasCutprotect=ui->lineEdit_11->text();
        gasPreflowplasma=ui->lineEdit_9->text();
        gasPreflowprotect=ui->lineEdit_12->text();


        serial.write(Gener_Message(17));// команда записи данных

     //   serial.write(Gener_Message(5)); //сила тока из плазменной системы
       // if(current.toInt() != ui->lineEdit->text().toInt())
       //     QMessageBox::information(this, "Error", "Ошибка установки значения номинального тока");

       // serial.write(Gener_Message(20)); //считать ток поворота системы
       // if(currentPercent.toInt() != ui->lineEdit_2->text().toInt())
      //      QMessageBox::information(this, "Error", "Ошибка установки тока попорота системы");

      //  serial.write(Gener_Message(22));  // Считать !заданные! значения для газов

       // if(gasCutplasma.toInt() != ui->lineEdit_10->text().toInt())
      //      QMessageBox::information(this, "Error", "Ошибка установки значения давления плазмообразующего газа при резке");

    //    if(gasCutprotect.toInt() != ui->lineEdit_11->text().toInt())
       //     QMessageBox::information(this, "Error", "Ошибка установки значения давления защитного газа при резке");
//
       // if(gasPreflowplasma.toInt() != ui->lineEdit_9->text().toInt())
       //     QMessageBox::information(this, "Error", "Ошибка установки значения давления плазмообразующего газа до возбуждения дуги");

       // if(gasPreflowprotect.toInt() != ui->lineEdit_12->text().toInt())
        //    QMessageBox::information(this, "Error", "Ошибка установки значения давления защитного газа до возбуждения дуги");

permiteMonitoring = 1;
m_timer.start(1000);
}

void MainWindow::on_pushButton_clicked() //функция отправки сообщения (сервис)
{

    serial.write(Gener_Message(ui->comboBox_4->currentIndex()));

}
