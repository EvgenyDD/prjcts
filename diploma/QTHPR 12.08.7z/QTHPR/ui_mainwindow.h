/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *action;
    QAction *action_2;
    QAction *action_3;
    QWidget *centralWidget;
    QGridLayout *gridLayout_2;
    QTabWidget *tabWidget;
    QWidget *tab;
    QPushButton *pushButton_3;
    QPushButton *pushButton_2;
    QLabel *label_2;
    QLineEdit *lineEdit;
    QLabel *label_3;
    QLineEdit *lineEdit_2;
    QComboBox *comboBox_2;
    QLabel *label_5;
    QLabel *label_6;
    QComboBox *comboBox_3;
    QGroupBox *groupBox;
    QLineEdit *lineEdit_12;
    QLabel *label_11;
    QLineEdit *lineEdit_9;
    QLabel *label_9;
    QGroupBox *groupBox_2;
    QLabel *label_16;
    QLineEdit *lineEdit_11;
    QLineEdit *lineEdit_10;
    QLabel *label_13;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QLineEdit *lineEdit_3;
    QLineEdit *lineEdit_6;
    QLineEdit *lineEdit_7;
    QLineEdit *lineEdit_8;
    QLabel *label_14;
    QLabel *label_15;
    QLabel *label_17;
    QLabel *label_18;
    QWidget *tab_2;
    QGroupBox *groupBox_3;
    QLineEdit *lineEdit_13;
    QLabel *label_4;
    QLineEdit *lineEdit_14;
    QLabel *label_10;
    QGroupBox *groupBox_4;
    QLineEdit *lineEdit_15;
    QLabel *label_12;
    QLineEdit *lineEdit_16;
    QLabel *label_19;
    QLabel *label_20;
    QLineEdit *lineEdit_17;
    QLineEdit *lineEdit_18;
    QLineEdit *lineEdit_19;
    QLineEdit *lineEdit_20;
    QLabel *label_21;
    QLabel *label_22;
    QLabel *label_23;
    QComboBox *comboBox_5;
    QPushButton *pushButton_6;
    QLabel *label_24;
    QPushButton *pushButton_7;
    QPushButton *pushButton_8;
    QGroupBox *groupBox_5;
    QLabel *label_25;
    QLabel *label_26;
    QLabel *label_27;
    QGroupBox *groupBox_6;
    QLineEdit *lineEdit_24;
    QLineEdit *lineEdit_25;
    QLineEdit *lineEdit_26;
    QLabel *label_30;
    QLabel *label_29;
    QLabel *label_28;
    QGroupBox *groupBox_7;
    QLabel *label_33;
    QLabel *label_32;
    QLabel *label_31;
    QLineEdit *lineEdit_27;
    QLineEdit *lineEdit_28;
    QLineEdit *lineEdit_29;
    QLabel *label_36;
    QLineEdit *lineEdit_30;
    QLineEdit *lineEdit_32;
    QLabel *label_34;
    QLineEdit *lineEdit_31;
    QLabel *label_35;
    QLabel *label_39;
    QLabel *label_37;
    QLineEdit *lineEdit_34;
    QLineEdit *lineEdit_33;
    QLineEdit *lineEdit_21;
    QLineEdit *lineEdit_22;
    QLineEdit *lineEdit_23;
    QGroupBox *groupBox_8;
    QLabel *label_38;
    QLabel *label_40;
    QLabel *label_41;
    QLineEdit *lineEdit_35;
    QLineEdit *lineEdit_36;
    QLineEdit *lineEdit_37;
    QLabel *label_42;
    QLineEdit *lineEdit_38;
    QLabel *label_43;
    QLineEdit *lineEdit_40;
    QLabel *label_44;
    QLabel *label_45;
    QLabel *label_46;
    QLabel *label_47;
    QLabel *label_48;
    QLabel *label_49;
    QLineEdit *lineEdit_39;
    QLineEdit *lineEdit_41;
    QLineEdit *lineEdit_42;
    QLineEdit *lineEdit_43;
    QLineEdit *lineEdit_44;
    QLineEdit *lineEdit_45;
    QLineEdit *lineEdit_46;
    QLineEdit *lineEdit_47;
    QWidget *tab_3;
    QLabel *label_8;
    QLabel *label_7;
    QLineEdit *lineEdit_4;
    QLineEdit *lineEdit_5;
    QPushButton *pushButton;
    QComboBox *comboBox_4;
    QComboBox *comboBox;
    QLabel *label;
    QPushButton *pushButton_9;
    QMenuBar *menuBar;
    QMenu *menu;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1182, 655);
        MainWindow->setStyleSheet(QLatin1String("QToolButton {\n"
"	color: #333;\n"
"	border: 0px;\n"
"	background: blue;\n"
" }\n"
"\n"
"\n"
"\n"
" QToolButton:checked {\n"
"	background-color: rgb(0, 255, 0);\n"
"\n"
"\n"
" }\n"
"\n"
" QToolButton::menu-button {\n"
"     border: 2px solid #555;\n"
"     width: 16px;\n"
" }"));
        action = new QAction(MainWindow);
        action->setObjectName(QStringLiteral("action"));
        action_2 = new QAction(MainWindow);
        action_2->setObjectName(QStringLiteral("action_2"));
        action_3 = new QAction(MainWindow);
        action_3->setObjectName(QStringLiteral("action_3"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        gridLayout_2 = new QGridLayout(centralWidget);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        pushButton_3 = new QPushButton(tab);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(420, 530, 161, 23));
        pushButton_2 = new QPushButton(tab);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(218, 528, 171, 23));
        label_2 = new QLabel(tab);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(26, 80, 111, 20));
        lineEdit = new QLineEdit(tab);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(200, 80, 113, 20));
        label_3 = new QLabel(tab);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(26, 120, 111, 20));
        lineEdit_2 = new QLineEdit(tab);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(200, 120, 113, 20));
        comboBox_2 = new QComboBox(tab);
        comboBox_2->setObjectName(QStringLiteral("comboBox_2"));
        comboBox_2->setEnabled(false);
        comboBox_2->setGeometry(QRect(200, 160, 181, 20));
        label_5 = new QLabel(tab);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(30, 160, 131, 20));
        label_6 = new QLabel(tab);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(30, 190, 131, 20));
        comboBox_3 = new QComboBox(tab);
        comboBox_3->setObjectName(QStringLiteral("comboBox_3"));
        comboBox_3->setEnabled(false);
        comboBox_3->setGeometry(QRect(200, 190, 181, 20));
        groupBox = new QGroupBox(tab);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(10, 230, 311, 81));
        lineEdit_12 = new QLineEdit(groupBox);
        lineEdit_12->setObjectName(QStringLiteral("lineEdit_12"));
        lineEdit_12->setGeometry(QRect(20, 50, 113, 20));
        label_11 = new QLabel(groupBox);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(150, 50, 111, 20));
        lineEdit_9 = new QLineEdit(groupBox);
        lineEdit_9->setObjectName(QStringLiteral("lineEdit_9"));
        lineEdit_9->setGeometry(QRect(20, 20, 113, 20));
        label_9 = new QLabel(groupBox);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(150, 20, 111, 20));
        groupBox_2 = new QGroupBox(tab);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        groupBox_2->setGeometry(QRect(10, 320, 311, 81));
        label_16 = new QLabel(groupBox_2);
        label_16->setObjectName(QStringLiteral("label_16"));
        label_16->setGeometry(QRect(150, 50, 111, 20));
        lineEdit_11 = new QLineEdit(groupBox_2);
        lineEdit_11->setObjectName(QStringLiteral("lineEdit_11"));
        lineEdit_11->setGeometry(QRect(20, 50, 113, 20));
        lineEdit_10 = new QLineEdit(groupBox_2);
        lineEdit_10->setObjectName(QStringLiteral("lineEdit_10"));
        lineEdit_10->setGeometry(QRect(20, 20, 113, 20));
        label_13 = new QLabel(groupBox_2);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setGeometry(QRect(150, 20, 111, 20));
        pushButton_4 = new QPushButton(tab);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(450, 170, 181, 41));
        pushButton_4->setCheckable(true);
        pushButton_5 = new QPushButton(tab);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(450, 80, 181, 41));
        pushButton_5->setCheckable(true);
        pushButton_5->setChecked(false);
        lineEdit_3 = new QLineEdit(tab);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        lineEdit_3->setEnabled(false);
        lineEdit_3->setGeometry(QRect(660, 80, 113, 20));
        lineEdit_6 = new QLineEdit(tab);
        lineEdit_6->setObjectName(QStringLiteral("lineEdit_6"));
        lineEdit_6->setEnabled(false);
        lineEdit_6->setGeometry(QRect(660, 110, 113, 20));
        lineEdit_7 = new QLineEdit(tab);
        lineEdit_7->setObjectName(QStringLiteral("lineEdit_7"));
        lineEdit_7->setEnabled(false);
        lineEdit_7->setGeometry(QRect(660, 170, 113, 20));
        lineEdit_8 = new QLineEdit(tab);
        lineEdit_8->setObjectName(QStringLiteral("lineEdit_8"));
        lineEdit_8->setEnabled(false);
        lineEdit_8->setGeometry(QRect(660, 200, 113, 20));
        label_14 = new QLabel(tab);
        label_14->setObjectName(QStringLiteral("label_14"));
        label_14->setGeometry(QRect(780, 80, 111, 20));
        label_15 = new QLabel(tab);
        label_15->setObjectName(QStringLiteral("label_15"));
        label_15->setGeometry(QRect(780, 170, 111, 20));
        label_17 = new QLabel(tab);
        label_17->setObjectName(QStringLiteral("label_17"));
        label_17->setGeometry(QRect(780, 200, 111, 20));
        label_18 = new QLabel(tab);
        label_18->setObjectName(QStringLiteral("label_18"));
        label_18->setGeometry(QRect(780, 110, 111, 20));
        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        groupBox_3 = new QGroupBox(tab_2);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        groupBox_3->setGeometry(QRect(30, 30, 271, 101));
        lineEdit_13 = new QLineEdit(groupBox_3);
        lineEdit_13->setObjectName(QStringLiteral("lineEdit_13"));
        lineEdit_13->setEnabled(false);
        lineEdit_13->setGeometry(QRect(110, 30, 151, 20));
        label_4 = new QLabel(groupBox_3);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(20, 30, 101, 16));
        lineEdit_14 = new QLineEdit(groupBox_3);
        lineEdit_14->setObjectName(QStringLiteral("lineEdit_14"));
        lineEdit_14->setEnabled(false);
        lineEdit_14->setGeometry(QRect(110, 60, 151, 20));
        label_10 = new QLabel(groupBox_3);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(20, 60, 101, 16));
        groupBox_4 = new QGroupBox(tab_2);
        groupBox_4->setObjectName(QStringLiteral("groupBox_4"));
        groupBox_4->setGeometry(QRect(330, 30, 431, 181));
        lineEdit_15 = new QLineEdit(groupBox_4);
        lineEdit_15->setObjectName(QStringLiteral("lineEdit_15"));
        lineEdit_15->setEnabled(false);
        lineEdit_15->setGeometry(QRect(190, 30, 151, 20));
        label_12 = new QLabel(groupBox_4);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(20, 30, 131, 16));
        lineEdit_16 = new QLineEdit(groupBox_4);
        lineEdit_16->setObjectName(QStringLiteral("lineEdit_16"));
        lineEdit_16->setEnabled(false);
        lineEdit_16->setGeometry(QRect(190, 60, 151, 20));
        label_19 = new QLabel(groupBox_4);
        label_19->setObjectName(QStringLiteral("label_19"));
        label_19->setGeometry(QRect(20, 60, 121, 16));
        label_20 = new QLabel(groupBox_4);
        label_20->setObjectName(QStringLiteral("label_20"));
        label_20->setGeometry(QRect(20, 110, 131, 16));
        lineEdit_17 = new QLineEdit(groupBox_4);
        lineEdit_17->setObjectName(QStringLiteral("lineEdit_17"));
        lineEdit_17->setEnabled(false);
        lineEdit_17->setGeometry(QRect(150, 110, 61, 20));
        lineEdit_18 = new QLineEdit(groupBox_4);
        lineEdit_18->setObjectName(QStringLiteral("lineEdit_18"));
        lineEdit_18->setEnabled(false);
        lineEdit_18->setGeometry(QRect(220, 110, 61, 20));
        lineEdit_19 = new QLineEdit(groupBox_4);
        lineEdit_19->setObjectName(QStringLiteral("lineEdit_19"));
        lineEdit_19->setEnabled(false);
        lineEdit_19->setGeometry(QRect(290, 110, 61, 20));
        lineEdit_20 = new QLineEdit(groupBox_4);
        lineEdit_20->setObjectName(QStringLiteral("lineEdit_20"));
        lineEdit_20->setEnabled(false);
        lineEdit_20->setGeometry(QRect(360, 110, 61, 20));
        label_21 = new QLabel(groupBox_4);
        label_21->setObjectName(QStringLiteral("label_21"));
        label_21->setGeometry(QRect(180, 90, 47, 13));
        label_22 = new QLabel(groupBox_4);
        label_22->setObjectName(QStringLiteral("label_22"));
        label_22->setGeometry(QRect(250, 90, 47, 13));
        label_23 = new QLabel(groupBox_4);
        label_23->setObjectName(QStringLiteral("label_23"));
        label_23->setGeometry(QRect(310, 90, 47, 13));
        comboBox_5 = new QComboBox(groupBox_4);
        comboBox_5->setObjectName(QStringLiteral("comboBox_5"));
        comboBox_5->setGeometry(QRect(20, 140, 131, 22));
        pushButton_6 = new QPushButton(groupBox_4);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setGeometry(QRect(200, 140, 121, 23));
        label_24 = new QLabel(tab_2);
        label_24->setObjectName(QStringLiteral("label_24"));
        label_24->setGeometry(QRect(720, 120, 47, 13));
        pushButton_7 = new QPushButton(tab_2);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        pushButton_7->setEnabled(true);
        pushButton_7->setGeometry(QRect(30, 170, 121, 41));
        pushButton_7->setCheckable(false);
        pushButton_8 = new QPushButton(tab_2);
        pushButton_8->setObjectName(QStringLiteral("pushButton_8"));
        pushButton_8->setGeometry(QRect(170, 170, 121, 41));
        pushButton_8->setCheckable(true);
        groupBox_5 = new QGroupBox(tab_2);
        groupBox_5->setObjectName(QStringLiteral("groupBox_5"));
        groupBox_5->setGeometry(QRect(30, 240, 1121, 331));
        label_25 = new QLabel(groupBox_5);
        label_25->setObjectName(QStringLiteral("label_25"));
        label_25->setGeometry(QRect(10, 30, 111, 16));
        label_26 = new QLabel(groupBox_5);
        label_26->setObjectName(QStringLiteral("label_26"));
        label_26->setGeometry(QRect(10, 70, 121, 16));
        label_27 = new QLabel(groupBox_5);
        label_27->setObjectName(QStringLiteral("label_27"));
        label_27->setGeometry(QRect(10, 110, 161, 16));
        groupBox_6 = new QGroupBox(groupBox_5);
        groupBox_6->setObjectName(QStringLiteral("groupBox_6"));
        groupBox_6->setGeometry(QRect(0, 140, 301, 181));
        lineEdit_24 = new QLineEdit(groupBox_6);
        lineEdit_24->setObjectName(QStringLiteral("lineEdit_24"));
        lineEdit_24->setEnabled(false);
        lineEdit_24->setGeometry(QRect(180, 120, 113, 20));
        lineEdit_25 = new QLineEdit(groupBox_6);
        lineEdit_25->setObjectName(QStringLiteral("lineEdit_25"));
        lineEdit_25->setEnabled(false);
        lineEdit_25->setGeometry(QRect(180, 80, 113, 20));
        lineEdit_26 = new QLineEdit(groupBox_6);
        lineEdit_26->setObjectName(QStringLiteral("lineEdit_26"));
        lineEdit_26->setEnabled(false);
        lineEdit_26->setGeometry(QRect(180, 40, 113, 20));
        label_30 = new QLabel(groupBox_6);
        label_30->setObjectName(QStringLiteral("label_30"));
        label_30->setGeometry(QRect(10, 80, 121, 16));
        label_29 = new QLabel(groupBox_6);
        label_29->setObjectName(QStringLiteral("label_29"));
        label_29->setGeometry(QRect(10, 120, 161, 16));
        label_28 = new QLabel(groupBox_6);
        label_28->setObjectName(QStringLiteral("label_28"));
        label_28->setGeometry(QRect(10, 40, 111, 16));
        groupBox_7 = new QGroupBox(groupBox_5);
        groupBox_7->setObjectName(QStringLiteral("groupBox_7"));
        groupBox_7->setGeometry(QRect(320, 20, 361, 301));
        label_33 = new QLabel(groupBox_7);
        label_33->setObjectName(QStringLiteral("label_33"));
        label_33->setGeometry(QRect(30, 20, 191, 16));
        label_32 = new QLabel(groupBox_7);
        label_32->setObjectName(QStringLiteral("label_32"));
        label_32->setGeometry(QRect(30, 80, 201, 16));
        label_31 = new QLabel(groupBox_7);
        label_31->setObjectName(QStringLiteral("label_31"));
        label_31->setGeometry(QRect(30, 50, 221, 16));
        lineEdit_27 = new QLineEdit(groupBox_7);
        lineEdit_27->setObjectName(QStringLiteral("lineEdit_27"));
        lineEdit_27->setEnabled(false);
        lineEdit_27->setGeometry(QRect(240, 50, 113, 20));
        lineEdit_28 = new QLineEdit(groupBox_7);
        lineEdit_28->setObjectName(QStringLiteral("lineEdit_28"));
        lineEdit_28->setEnabled(false);
        lineEdit_28->setGeometry(QRect(240, 20, 113, 20));
        lineEdit_29 = new QLineEdit(groupBox_7);
        lineEdit_29->setObjectName(QStringLiteral("lineEdit_29"));
        lineEdit_29->setEnabled(false);
        lineEdit_29->setGeometry(QRect(240, 80, 113, 20));
        label_36 = new QLabel(groupBox_7);
        label_36->setObjectName(QStringLiteral("label_36"));
        label_36->setGeometry(QRect(30, 110, 211, 16));
        lineEdit_30 = new QLineEdit(groupBox_7);
        lineEdit_30->setObjectName(QStringLiteral("lineEdit_30"));
        lineEdit_30->setEnabled(false);
        lineEdit_30->setGeometry(QRect(240, 140, 113, 20));
        lineEdit_32 = new QLineEdit(groupBox_7);
        lineEdit_32->setObjectName(QStringLiteral("lineEdit_32"));
        lineEdit_32->setEnabled(false);
        lineEdit_32->setGeometry(QRect(240, 170, 113, 20));
        label_34 = new QLabel(groupBox_7);
        label_34->setObjectName(QStringLiteral("label_34"));
        label_34->setGeometry(QRect(30, 140, 121, 16));
        lineEdit_31 = new QLineEdit(groupBox_7);
        lineEdit_31->setObjectName(QStringLiteral("lineEdit_31"));
        lineEdit_31->setEnabled(false);
        lineEdit_31->setGeometry(QRect(240, 110, 113, 20));
        label_35 = new QLabel(groupBox_7);
        label_35->setObjectName(QStringLiteral("label_35"));
        label_35->setGeometry(QRect(30, 170, 161, 16));
        label_39 = new QLabel(groupBox_7);
        label_39->setObjectName(QStringLiteral("label_39"));
        label_39->setGeometry(QRect(30, 200, 191, 16));
        label_37 = new QLabel(groupBox_7);
        label_37->setObjectName(QStringLiteral("label_37"));
        label_37->setGeometry(QRect(30, 230, 211, 16));
        lineEdit_34 = new QLineEdit(groupBox_7);
        lineEdit_34->setObjectName(QStringLiteral("lineEdit_34"));
        lineEdit_34->setEnabled(false);
        lineEdit_34->setGeometry(QRect(240, 200, 113, 20));
        lineEdit_33 = new QLineEdit(groupBox_7);
        lineEdit_33->setObjectName(QStringLiteral("lineEdit_33"));
        lineEdit_33->setEnabled(false);
        lineEdit_33->setGeometry(QRect(240, 230, 113, 20));
        lineEdit_21 = new QLineEdit(groupBox_5);
        lineEdit_21->setObjectName(QStringLiteral("lineEdit_21"));
        lineEdit_21->setEnabled(false);
        lineEdit_21->setGeometry(QRect(180, 30, 113, 20));
        lineEdit_22 = new QLineEdit(groupBox_5);
        lineEdit_22->setObjectName(QStringLiteral("lineEdit_22"));
        lineEdit_22->setEnabled(false);
        lineEdit_22->setGeometry(QRect(180, 70, 113, 20));
        lineEdit_23 = new QLineEdit(groupBox_5);
        lineEdit_23->setObjectName(QStringLiteral("lineEdit_23"));
        lineEdit_23->setEnabled(false);
        lineEdit_23->setGeometry(QRect(180, 110, 113, 20));
        groupBox_8 = new QGroupBox(groupBox_5);
        groupBox_8->setObjectName(QStringLiteral("groupBox_8"));
        groupBox_8->setGeometry(QRect(690, 20, 421, 301));
        label_38 = new QLabel(groupBox_8);
        label_38->setObjectName(QStringLiteral("label_38"));
        label_38->setGeometry(QRect(10, 20, 121, 16));
        label_40 = new QLabel(groupBox_8);
        label_40->setObjectName(QStringLiteral("label_40"));
        label_40->setGeometry(QRect(10, 80, 171, 16));
        label_41 = new QLabel(groupBox_8);
        label_41->setObjectName(QStringLiteral("label_41"));
        label_41->setGeometry(QRect(10, 50, 161, 16));
        lineEdit_35 = new QLineEdit(groupBox_8);
        lineEdit_35->setObjectName(QStringLiteral("lineEdit_35"));
        lineEdit_35->setEnabled(false);
        lineEdit_35->setGeometry(QRect(280, 50, 113, 20));
        lineEdit_36 = new QLineEdit(groupBox_8);
        lineEdit_36->setObjectName(QStringLiteral("lineEdit_36"));
        lineEdit_36->setEnabled(false);
        lineEdit_36->setGeometry(QRect(280, 20, 113, 20));
        lineEdit_37 = new QLineEdit(groupBox_8);
        lineEdit_37->setObjectName(QStringLiteral("lineEdit_37"));
        lineEdit_37->setEnabled(false);
        lineEdit_37->setGeometry(QRect(280, 80, 113, 20));
        label_42 = new QLabel(groupBox_8);
        label_42->setObjectName(QStringLiteral("label_42"));
        label_42->setGeometry(QRect(10, 110, 221, 16));
        lineEdit_38 = new QLineEdit(groupBox_8);
        lineEdit_38->setObjectName(QStringLiteral("lineEdit_38"));
        lineEdit_38->setEnabled(false);
        lineEdit_38->setGeometry(QRect(280, 140, 113, 20));
        label_43 = new QLabel(groupBox_8);
        label_43->setObjectName(QStringLiteral("label_43"));
        label_43->setGeometry(QRect(10, 140, 261, 16));
        lineEdit_40 = new QLineEdit(groupBox_8);
        lineEdit_40->setObjectName(QStringLiteral("lineEdit_40"));
        lineEdit_40->setEnabled(false);
        lineEdit_40->setGeometry(QRect(280, 110, 113, 20));
        label_44 = new QLabel(tab_2);
        label_44->setObjectName(QStringLiteral("label_44"));
        label_44->setGeometry(QRect(770, 60, 71, 21));
        label_45 = new QLabel(tab_2);
        label_45->setObjectName(QStringLiteral("label_45"));
        label_45->setGeometry(QRect(770, 100, 71, 16));
        label_46 = new QLabel(tab_2);
        label_46->setObjectName(QStringLiteral("label_46"));
        label_46->setGeometry(QRect(830, 40, 91, 21));
        label_47 = new QLabel(tab_2);
        label_47->setObjectName(QStringLiteral("label_47"));
        label_47->setGeometry(QRect(930, 40, 91, 21));
        label_48 = new QLabel(tab_2);
        label_48->setObjectName(QStringLiteral("label_48"));
        label_48->setGeometry(QRect(1030, 40, 71, 21));
        label_49 = new QLabel(tab_2);
        label_49->setObjectName(QStringLiteral("label_49"));
        label_49->setGeometry(QRect(1080, 40, 81, 21));
        lineEdit_39 = new QLineEdit(tab_2);
        lineEdit_39->setObjectName(QStringLiteral("lineEdit_39"));
        lineEdit_39->setEnabled(false);
        lineEdit_39->setGeometry(QRect(840, 60, 81, 20));
        lineEdit_41 = new QLineEdit(tab_2);
        lineEdit_41->setObjectName(QStringLiteral("lineEdit_41"));
        lineEdit_41->setEnabled(false);
        lineEdit_41->setGeometry(QRect(840, 100, 81, 20));
        lineEdit_42 = new QLineEdit(tab_2);
        lineEdit_42->setObjectName(QStringLiteral("lineEdit_42"));
        lineEdit_42->setEnabled(false);
        lineEdit_42->setGeometry(QRect(930, 60, 81, 20));
        lineEdit_43 = new QLineEdit(tab_2);
        lineEdit_43->setObjectName(QStringLiteral("lineEdit_43"));
        lineEdit_43->setEnabled(false);
        lineEdit_43->setGeometry(QRect(930, 100, 81, 20));
        lineEdit_44 = new QLineEdit(tab_2);
        lineEdit_44->setObjectName(QStringLiteral("lineEdit_44"));
        lineEdit_44->setEnabled(false);
        lineEdit_44->setGeometry(QRect(1030, 60, 51, 20));
        lineEdit_45 = new QLineEdit(tab_2);
        lineEdit_45->setObjectName(QStringLiteral("lineEdit_45"));
        lineEdit_45->setEnabled(false);
        lineEdit_45->setGeometry(QRect(1030, 100, 51, 20));
        lineEdit_46 = new QLineEdit(tab_2);
        lineEdit_46->setObjectName(QStringLiteral("lineEdit_46"));
        lineEdit_46->setEnabled(false);
        lineEdit_46->setGeometry(QRect(1090, 60, 61, 20));
        lineEdit_47 = new QLineEdit(tab_2);
        lineEdit_47->setObjectName(QStringLiteral("lineEdit_47"));
        lineEdit_47->setEnabled(false);
        lineEdit_47->setGeometry(QRect(1090, 100, 61, 20));
        tabWidget->addTab(tab_2, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        label_8 = new QLabel(tab_3);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(256, 140, 81, 20));
        label_7 = new QLabel(tab_3);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(380, 30, 131, 16));
        lineEdit_4 = new QLineEdit(tab_3);
        lineEdit_4->setObjectName(QStringLiteral("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(370, 60, 201, 20));
        lineEdit_5 = new QLineEdit(tab_3);
        lineEdit_5->setObjectName(QStringLiteral("lineEdit_5"));
        lineEdit_5->setGeometry(QRect(360, 140, 201, 20));
        pushButton = new QPushButton(tab_3);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(60, 60, 181, 23));
        comboBox_4 = new QComboBox(tab_3);
        comboBox_4->setObjectName(QStringLiteral("comboBox_4"));
        comboBox_4->setGeometry(QRect(250, 60, 111, 22));
        comboBox = new QComboBox(tab_3);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(60, 230, 181, 20));
        label = new QLabel(tab_3);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(260, 230, 169, 16));
        pushButton_9 = new QPushButton(tab_3);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));
        pushButton_9->setGeometry(QRect(630, 60, 181, 61));
        pushButton_9->setCheckable(true);
        pushButton_9->setChecked(false);
        tabWidget->addTab(tab_3, QString());

        gridLayout_2->addWidget(tabWidget, 0, 0, 1, 1);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1182, 21));
        menu = new QMenu(menuBar);
        menu->setObjectName(QStringLiteral("menu"));
        MainWindow->setMenuBar(menuBar);

        menuBar->addAction(menu->menuAction());
        menu->addAction(action);
        menu->addAction(action_2);
        menu->addAction(action_3);

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(0);
        comboBox_2->setCurrentIndex(5);
        comboBox_3->setCurrentIndex(5);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0));
        action->setText(QApplication::translate("MainWindow", "\320\241\320\276\321\205\321\200\320\260\320\275\320\270\321\202\321\214 \320\277\320\260\321\200\320\260\320\265\321\202\321\200\321\213 \320\262 \321\204\320\260\320\271\320\273", 0));
        action_2->setText(QApplication::translate("MainWindow", "\320\227\320\260\320\263\321\200\321\203\320\267\320\270\321\202\321\214 \320\277\320\260\321\200\320\260\320\274\320\265\321\202\321\200\321\213 \320\270\320\267 \321\204\320\260\320\271\320\273\320\260", 0));
        action_3->setText(QApplication::translate("MainWindow", "\320\227\320\260\320\272\321\200\321\213\321\202\321\214 \320\277\321\200\320\276\320\263\321\200\320\260\320\274\320\274\321\203", 0));
        pushButton_3->setText(QApplication::translate("MainWindow", "\320\227\320\260\320\277\320\270\321\201\320\260\321\202\321\214 \320\264\320\260\320\275\320\275\321\213\320\265 \320\262 \320\270\321\201\321\202\320\276\321\207\320\275\320\270\320\272", 0));
        pushButton_2->setText(QApplication::translate("MainWindow", "\320\241\321\207\320\270\321\202\320\260\321\202\321\214 \320\264\320\260\320\275\320\275\321\213\320\265 \320\270\320\267 \320\270\321\201\321\202\320\276\321\207\320\275\320\270\320\272\320\260", 0));
        label_2->setText(QApplication::translate("MainWindow", "\320\227\320\260\320\264\320\260\320\275\320\275\321\213\320\271 \321\202\320\276\320\272", 0));
        lineEdit->setInputMask(QString());
        lineEdit->setText(QApplication::translate("MainWindow", "260", 0));
        label_3->setText(QApplication::translate("MainWindow", "\320\242\320\276\320\272 \320\275\320\260 \321\203\320\263\320\273\320\260\321\205 \320\272\320\276\320\275\321\202\321\203\321\200\320\260", 0));
        lineEdit_2->setText(QApplication::translate("MainWindow", "75", 0));
        comboBox_2->clear();
        comboBox_2->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "\320\235\320\265\321\202 \320\263\320\260\320\267\320\260", 0)
         << QApplication::translate("MainWindow", "\320\232\320\270\321\201\320\273\320\276\321\200\320\276\320\264", 0)
         << QApplication::translate("MainWindow", "\320\234\320\265\321\202\320\260\320\275 CH4 (\320\275\320\265 \320\277\320\276\320\264\320\264\320\265\321\200\320\266\320\270\320\262\320\260\320\265\321\202\321\201\321\217)", 0)
         << QApplication::translate("MainWindow", "H35 (\320\260\321\200\320\263\320\276\320\275-\320\262\320\276\320\264\320\276\321\200\320\276\320\264)", 0)
         << QApplication::translate("MainWindow", "H5 (\320\275\320\265 \320\277\320\276\320\264\320\264\320\265\321\200\320\266\320\270\320\262\320\260\320\265\321\202\321\201\321\217)", 0)
         << QApplication::translate("MainWindow", "\320\222\320\276\320\267\320\264\321\203\321\205", 0)
         << QApplication::translate("MainWindow", "\320\220\320\267\320\276\321\202", 0)
         << QApplication::translate("MainWindow", "\320\220\321\200\320\263\320\276\320\275", 0)
         << QApplication::translate("MainWindow", "F5 (N95)", 0)
        );
        label_5->setText(QApplication::translate("MainWindow", "\320\237\320\273\320\260\320\267\320\274\320\276\320\276\320\261\321\200\320\260\320\267\321\203\321\216\321\211\320\270\320\271 \320\263\320\260\320\267", 0));
        label_6->setText(QApplication::translate("MainWindow", "\320\227\320\260\321\211\320\270\321\202\320\275\321\213\320\271 \320\263\320\260\320\267", 0));
        comboBox_3->clear();
        comboBox_3->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "\320\235\320\265\321\202 \320\263\320\260\320\267\320\260", 0)
         << QApplication::translate("MainWindow", "\320\232\320\270\321\201\320\273\320\276\321\200\320\276\320\264", 0)
         << QApplication::translate("MainWindow", "\320\234\320\265\321\202\320\260\320\275 CH4 (\320\275\320\265 \320\277\320\276\320\264\320\264\320\265\321\200\320\266\320\270\320\262\320\260\321\216\321\202\321\201\321\217)", 0)
         << QApplication::translate("MainWindow", "H35 (\320\260\321\200\320\263\320\276\320\275-\320\262\320\276\320\264\320\276\321\200\320\276\320\264)", 0)
         << QApplication::translate("MainWindow", "H5 (\320\275\320\265 \320\277\320\276\320\264\320\264\320\265\321\200\320\266\320\270\320\262\320\260\320\265\321\202\321\201\321\217)", 0)
         << QApplication::translate("MainWindow", "\320\222\320\276\320\267\320\264\321\203\321\205", 0)
         << QApplication::translate("MainWindow", "\320\220\320\267\320\276\321\202", 0)
         << QApplication::translate("MainWindow", "\320\220\321\200\320\263\320\276\320\275", 0)
         << QApplication::translate("MainWindow", "F5 (N95)", 0)
        );
        groupBox->setTitle(QApplication::translate("MainWindow", "\320\237\320\276\320\264\320\260\321\207\320\260 \320\263\320\260\320\267\320\276\320\262 \320\264\320\276 \320\262\320\276\320\267\320\261\321\203\320\266\320\264\320\265\320\275\320\270\321\217 \320\264\321\203\320\263\320\270", 0));
        lineEdit_12->setText(QApplication::translate("MainWindow", "300", 0));
        label_11->setText(QApplication::translate("MainWindow", "\320\227\320\260\321\211\320\270\321\202\320\275\321\213\320\271 \320\263\320\260\320\267", 0));
        lineEdit_9->setText(QApplication::translate("MainWindow", "400", 0));
        label_9->setText(QApplication::translate("MainWindow", "\320\237\320\273\320\260\320\267\320\274\320\260-\320\263\320\260\320\267", 0));
        groupBox_2->setTitle(QApplication::translate("MainWindow", "\320\237\320\276\320\264\320\260\321\207\320\260 \320\263\320\260\320\267\320\276\320\262 \320\277\321\200\320\270 \321\200\320\265\320\267\320\272\320\265", 0));
        label_16->setText(QApplication::translate("MainWindow", "\320\227\320\260\321\211\320\270\321\202\320\275\321\213\320\271 \320\263\320\260\320\267", 0));
        lineEdit_11->setText(QApplication::translate("MainWindow", "100", 0));
        lineEdit_10->setText(QApplication::translate("MainWindow", "200", 0));
        label_13->setText(QApplication::translate("MainWindow", "\320\237\320\273\320\260\320\267\320\274\320\260-\320\263\320\260\320\267", 0));
        pushButton_4->setText(QApplication::translate("MainWindow", "\320\242\320\265\321\201\321\202 \321\200\320\265\320\266\321\203\321\211\320\265\320\271 \320\277\320\276\320\264\320\260\321\207\320\270 \320\263\320\260\320\267\320\276\320\262", 0));
        pushButton_5->setText(QApplication::translate("MainWindow", "\320\242\320\265\321\201\321\202 \320\277\321\200\320\276\320\264\321\203\320\262\320\276\321\207\320\275\320\276\320\271 \320\277\320\276\320\264\320\260\321\207\320\270 \320\263\320\260\320\267\320\276\320\262", 0));
        label_14->setText(QApplication::translate("MainWindow", "\320\237\320\273\320\260\320\267\320\274\320\260-\320\263\320\260\320\267", 0));
        label_15->setText(QApplication::translate("MainWindow", "\320\237\320\273\320\260\320\267\320\274\320\260-\320\263\320\260\320\267", 0));
        label_17->setText(QApplication::translate("MainWindow", "\320\227\320\260\321\211\320\270\321\202\320\275\321\213\320\271 \320\263\320\260\320\267", 0));
        label_18->setText(QApplication::translate("MainWindow", "\320\227\320\260\321\211\320\270\321\202\320\275\321\213\320\271 \320\263\320\260\320\267", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("MainWindow", "\320\237\320\260\321\200\320\260\320\274\320\265\321\202\321\200\320\270\321\200\320\276\320\262\320\260\320\275\320\270\320\265", 0));
        groupBox_3->setTitle(QApplication::translate("MainWindow", "\320\242\320\265\320\272\321\203\321\211\320\265\320\265 \321\201\320\276\321\201\321\202\320\276\321\217\320\275\320\270\320\265 \320\270\321\201\321\202\320\276\321\207\320\275\320\270\320\272\320\260 \320\277\320\273\320\260\320\267\320\274\320\265\320\275\320\275\320\276\320\271 \321\200\320\265\320\267\320\272\320\270", 0));
        label_4->setText(QApplication::translate("MainWindow", "\320\232\320\276\320\264 \321\201\320\276\321\201\321\202\320\276\321\217\320\275\320\270\321\217", 0));
        label_10->setText(QApplication::translate("MainWindow", "\320\241\320\276\321\201\321\202\320\276\321\217\320\275\320\270\320\265", 0));
        groupBox_4->setTitle(QApplication::translate("MainWindow", "\320\236\321\210\320\270\320\261\320\272\320\270 \320\270\321\201\321\202\320\276\321\207\320\275\320\270\320\272\320\260 \320\277\320\273\320\260\320\267\320\274\320\265\320\275\320\275\320\276\320\271 \321\200\320\265\320\267\320\272\320\270", 0));
        label_12->setText(QApplication::translate("MainWindow", "\320\232\320\276\320\264 \320\277\320\276\321\201\320\273\320\265\320\264\320\275\320\265\320\271 \320\276\321\210\320\270\320\261\320\272\320\270", 0));
        label_19->setText(QApplication::translate("MainWindow", "\320\242\320\270\320\277 \320\277\320\276\321\201\320\273\320\265\320\264\320\275\320\265\320\271 \320\276\321\210\320\270\320\261\320\272\320\270", 0));
        label_20->setText(QApplication::translate("MainWindow", "\320\232\320\276\320\264\321\213 \320\277\320\276\321\201\320\273\320\265\320\264\320\275\320\270\321\205 \320\276\321\210\320\270\320\261\320\276\320\272", 0));
        label_21->setText(QApplication::translate("MainWindow", "1", 0));
        label_22->setText(QApplication::translate("MainWindow", "2", 0));
        label_23->setText(QApplication::translate("MainWindow", "3", 0));
        comboBox_5->clear();
        comboBox_5->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "\320\242\320\265\320\272\321\203\321\211\320\260\321\217 \320\276\321\210\320\270\320\261\320\272\320\260", 0)
         << QApplication::translate("MainWindow", "\320\236\321\210\320\270\320\261\320\272\320\260 \342\204\2261", 0)
         << QApplication::translate("MainWindow", "\320\236\321\210\320\270\320\261\320\272\320\260 \342\204\2262", 0)
         << QApplication::translate("MainWindow", "\320\236\321\210\320\270\320\261\320\272\320\260 \342\204\2263", 0)
         << QApplication::translate("MainWindow", "\320\236\321\210\320\270\320\261\320\272\320\260 \342\204\2264", 0)
        );
        pushButton_6->setText(QApplication::translate("MainWindow", "\320\237\320\276\320\274\320\276\321\211\321\214", 0));
        label_24->setText(QApplication::translate("MainWindow", "4", 0));
        pushButton_7->setText(QApplication::translate("MainWindow", "\320\241\320\261\321\200\320\276\321\201 \320\230\320\237\320\240", 0));
        pushButton_8->setText(QApplication::translate("MainWindow", "\320\222\320\272\320\273. \320\275\320\260\321\201\320\276\321\201 \320\262\321\200\321\203\321\207\320\275\321\203\321\216", 0));
        groupBox_5->setTitle(QApplication::translate("MainWindow", "\320\234\320\276\320\275\320\270\321\202\320\276\321\200\320\270\320\275\320\263 \320\264\320\260\320\275\320\275\321\213\321\205 \320\270 \321\201\321\202\320\260\321\202\320\270\321\201\321\202\320\270\320\272\320\260", 0));
        label_25->setText(QApplication::translate("MainWindow", "\320\233\320\270\320\275\320\265\320\271\320\275\320\276\320\265 \320\275\320\260\321\200\321\217\320\266\320\265\320\275\320\270\320\265", 0));
        label_26->setText(QApplication::translate("MainWindow", "\320\242\320\276\320\272 \321\200\320\260\320\261\320\276\321\207\320\265\320\263\320\276 \320\277\321\200\320\276\320\262\320\276\320\264\320\260", 0));
        label_27->setText(QApplication::translate("MainWindow", "\320\242\320\265\320\274\320\277\320\265\321\200\320\260\321\202\321\203\321\200\320\260 \321\202\321\200\320\260\320\275\321\201\321\204\320\276\321\200\320\274\320\260\321\202\320\276\321\200\320\260", 0));
        groupBox_6->setTitle(QApplication::translate("MainWindow", "\320\236\321\205\320\273\320\260\320\266\320\264\320\260\321\216\321\211\320\260\321\217 \320\266\320\270\320\264\320\272\320\276\321\201\321\202\321\214", 0));
        label_30->setText(QApplication::translate("MainWindow", "\320\224\320\260\320\262\320\273\320\265\320\275\320\270\320\265", 0));
        label_29->setText(QApplication::translate("MainWindow", "\320\237\320\276\321\202\320\276\320\272", 0));
        label_28->setText(QApplication::translate("MainWindow", "\320\242\320\265\320\274\320\277\320\265\321\200\320\260\321\202\321\203\321\200\320\260", 0));
        groupBox_7->setTitle(QApplication::translate("MainWindow", "\320\224\320\260\320\262\320\273\320\265\320\275\320\270\321\217 \320\263\320\260\320\267\320\276\320\262", 0));
        label_33->setText(QApplication::translate("MainWindow", "\320\240\320\265\320\266\321\203\321\211\320\265\320\265 \320\264\320\260\320\262\320\273\320\265\320\275\320\270\320\265 \320\277\320\273\320\260\320\267\320\274\320\276\320\276\320\261\321\200. \320\263\320\260\320\267\320\260", 0));
        label_32->setText(QApplication::translate("MainWindow", "\320\240\320\265\320\266\321\203\321\211\320\265\320\265 \320\264\320\260\320\262\320\273\320\265\320\275\320\270\320\265 \320\267\320\260\321\211\320\270\321\202\320\275\320\276\320\263\320\276 \320\263\320\260\320\267\320\260", 0));
        label_31->setText(QApplication::translate("MainWindow", "\320\237\321\200\320\276\320\264\321\203\320\262\320\276\321\207\320\275\320\276\320\265 \320\264\320\260\320\262\320\273\320\265\320\275\320\270\320\265 \320\277\320\273\320\260\320\267\320\274\320\276\320\276\320\261\321\200. \320\263\320\260\320\267\320\260", 0));
        label_36->setText(QApplication::translate("MainWindow", "\320\237\321\200\320\276\320\264\321\203\320\262\320\276\321\207\320\275\320\276\320\265 \320\264\320\260\320\262\320\273\320\265\320\275\320\270\320\265 \320\267\320\260\321\211\320\270\321\202\320\275\320\276\320\263\320\276 \320\263\320\260\320\267\320\260", 0));
        label_34->setText(QApplication::translate("MainWindow", "\320\224\320\260\320\262\320\273\320\265\320\275\320\270\320\265 \320\263\320\260\320\267\320\260 1", 0));
        label_35->setText(QApplication::translate("MainWindow", "\320\224\320\260\320\262\320\273\320\265\320\275\320\270\320\265 \320\263\320\260\320\267\320\260 2", 0));
        label_39->setText(QApplication::translate("MainWindow", "\320\224\320\260\320\262\320\273\320\265\320\275\320\270\320\265 \320\260\320\267\320\276\321\202\320\260 \320\264\320\273\321\217 \321\201\320\274\320\265\321\210\320\270\320\262\320\260\320\275\320\270\321\217", 0));
        label_37->setText(QApplication::translate("MainWindow", "\320\224\320\260\320\262\320\273\320\265\320\275\320\270\320\265 \320\263\320\260\320\267\320\260 \342\204\226 2 \320\264\320\273\321\217 \321\201\320\274\320\265\321\210\320\270\320\262\320\260\320\275\320\270\321\217", 0));
        groupBox_8->setTitle(QApplication::translate("MainWindow", "\320\241\321\202\320\260\321\202\320\270\321\201\321\202\320\270\320\272\320\260 \321\200\320\260\320\261\320\276\321\202\321\213", 0));
        label_38->setText(QApplication::translate("MainWindow", "\320\241\321\203\320\274\320\274\320\260\321\200\320\275\320\276\320\265 \320\262\321\200\320\265\320\274\321\217 \320\264\321\203\320\263\320\270", 0));
        label_40->setText(QApplication::translate("MainWindow", "\320\241\321\203\320\274\320\260\321\200\320\275\320\276\320\265 \321\207\320\270\321\201\320\273\320\276 \320\277\320\265\321\200\320\265\320\275\320\276\321\201\320\276\320\262 \320\264\321\203\320\263\320\270", 0));
        label_41->setText(QApplication::translate("MainWindow", "\320\241\321\203\320\274\320\274\320\260\321\200\320\275\320\276\320\265 \320\262\321\200\320\265\320\274\321\217 \321\200\320\260\320\261\320\276\321\202\321\213 \320\230\320\237\320\240", 0));
        label_42->setText(QApplication::translate("MainWindow", "\320\241\321\203\320\274\320\274\320\260\321\200\320\275\320\276\320\265 \321\207\320\270\321\201\320\273\320\276 \320\275\320\265\321\203\320\264\320\260\321\207 \320\277\320\265\321\200\320\265\320\275\320\276\321\201\320\260 \320\264\321\203\320\263\320\270", 0));
        label_43->setText(QApplication::translate("MainWindow", "\320\241\321\203\320\274\320\274\320\260\321\200\320\275\320\276\320\265 \321\207\320\270\321\201\320\273\320\276 \320\276\321\210\320\270\320\261\320\276\320\272 \320\277\320\273\320\260\320\262\320\275\320\276\320\263\320\276 \320\262\321\213\320\272\320\273\321\216\321\207\320\265\320\275\320\270\321\217", 0));
        label_44->setText(QApplication::translate("MainWindow", "\320\230\320\275\320\262\320\265\321\200\321\202\320\276\321\200 \320\220", 0));
        label_45->setText(QApplication::translate("MainWindow", "\320\230\320\275\320\262\320\265\321\200\321\202\320\276\321\200 B", 0));
        label_46->setText(QApplication::translate("MainWindow", "\320\227\320\260\320\264\320\260\320\275\320\275\321\213\320\271 \321\202\320\276\320\272, \320\220", 0));
        label_47->setText(QApplication::translate("MainWindow", "\320\242\320\265\320\272\321\203\321\211\320\270\320\271 \321\202\320\276\320\272, \320\220", 0));
        label_48->setText(QApplication::translate("MainWindow", "\320\250\320\230\320\234, %", 0));
        label_49->setText(QApplication::translate("MainWindow", "\320\242\320\265\320\274\320\277\320\265\321\200., \320\264\320\270\321\201\320\272\321\200", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("MainWindow", "\320\234\320\276\320\275\320\270\321\202\320\276\321\200\320\270\320\275\320\263", 0));
        label_8->setText(QApplication::translate("MainWindow", "\320\241\320\270\320\273\320\260 \321\202\320\276\320\272\320\260", 0));
        label_7->setText(QApplication::translate("MainWindow", "\320\236\321\202\320\262\320\265\321\202", 0));
        lineEdit_5->setText(QString());
        pushButton->setText(QApplication::translate("MainWindow", "\320\236\321\202\320\277\321\200\320\260\320\262\320\270\321\202\321\214 \320\272\320\276\320\274\320\260\320\275\320\264\321\203", 0));
        comboBox_4->clear();
        comboBox_4->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "Hello", 0)
         << QApplication::translate("MainWindow", "Version", 0)
         << QApplication::translate("MainWindow", "Get State", 0)
         << QApplication::translate("MainWindow", "Last Error", 0)
         << QApplication::translate("MainWindow", "Remote Mode", 0)
         << QApplication::translate("MainWindow", "Read Plasma Amps", 0)
         << QApplication::translate("MainWindow", "Set Nominal Amps", 0)
        );
        label->setText(QApplication::translate("MainWindow", "\320\222\321\213\320\261\320\276\321\200 \320\277\320\276\321\201\320\273\320\265\320\264\320\276\320\262\320\260\321\202\320\265\320\273\321\214\320\275\320\276\320\263\320\276 \320\277\320\276\321\200\321\202\320\260", 0));
        pushButton_9->setText(QApplication::translate("MainWindow", "\320\236\321\201\321\202\320\260\320\275\320\276\320\262\320\270\321\202\321\214 \320\273\321\216\320\261\320\276\320\271 \320\274\320\276\320\275\320\270\321\202\320\276\321\200\320\270\320\275\320\263", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("MainWindow", "\320\241\320\265\321\200\320\262\320\270\321\201", 0));
        menu->setTitle(QApplication::translate("MainWindow", "\320\222\320\272\320\273\320\260\320\264\320\272\320\270", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
